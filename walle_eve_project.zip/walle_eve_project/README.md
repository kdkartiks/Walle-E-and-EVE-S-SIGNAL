# WALL-E and EVE's Signal — recruitment prototype

A small, standard-library-only Python autonomous search-agent simulation.

## Run

Requires Python 3.9+; no external packages.

```bash
python main.py --config sample_config.json --output mission_report.json
```

The console prints a step-by-step trace; `mission_report.json` stores observations, actions, reasons, best guesses, confidence, and a final report.

## Design

- **Environment** owns the map, EVE's hidden location, sensor noise, and scans.
- **Agent** only sees the starting position, noisy distance readings, and scan responses. It never reads the hidden location for its movement decisions. The environment checks mission success after each move.
- **Belief** is a probability distribution over candidate cells. Start uniform, then use likelihood filtering and normalization for every signal or scan.
- **Planning** chooses among legal adjacent cells by expected distance to EVE, a revisit penalty, and a recharge incentive when energy is low.
- **Resources** include battery, action costs, time limit, and recharge stations.

## Config fields

`width`, `height`, `start`, `eve`, `walls`, `recharge_stations`, `battery`, `move_cost`, `scan_cost`, `time_limit`, `scan_range`, `signal_noise`, `seed`.

Coordinates use `[x, y]`, starting at `[0,0]` in the top-left. `eve` is known only to the environment.

## Limitations and future work

This is a baseline, not an optimal search algorithm. The belief update uses a simple bounded-uniform noise model; it does not model obstacles in the distance signal. The greedy planner can get stuck in local patterns, and recharge behavior is simplistic. Scans reveal whether EVE is nearby, not an exact location. Improvements: shortest-path routing to recharge, information-gain-based scanning, heatmap visualization, and benchmark results across random seeds/maps.

## Suggested evaluation

Run with several `eve`, `seed`, and `signal_noise` values; report success rate, moves/time, battery consumed, and final location confidence. Keep both successful and unsuccessful runs.

## Submission note

Review and test the code, understand the belief update and action policy, and follow your club's rules on AI assistance before submitting. Do not claim features or experiments you have not completed.
