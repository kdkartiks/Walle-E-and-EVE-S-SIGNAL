"""WALL-E and EVE's Signal: a small autonomous search-agent simulation.

Only the environment knows EVE's actual location. The agent maintains a
probability distribution over possible locations and updates it from scans.
"""
import argparse
import json
import math
import random
from pathlib import Path

MOVES = {'N': (0, -1), 'S': (0, 1), 'E': (1, 0), 'W': (-1, 0)}


def distance(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


class Environment:
    def __init__(self, config):
        self.width = config['width']
        self.height = config['height']
        self.start = tuple(config['start'])
        self.eve = tuple(config['eve'])
        self.walls = {tuple(p) for p in config.get('walls', [])}
        self.recharge = {tuple(p) for p in config.get('recharge_stations', [])}
        self.scan_range = config.get('scan_range', 2)
        self.noise = config.get('signal_noise', 1)
        self.rng = random.Random(config.get('seed', 42))
        self.cells = [(x, y) for y in range(self.height) for x in range(self.width)
                      if (x, y) not in self.walls]
        for p in (self.start, self.eve):
            if p not in self.cells:
                raise ValueError('Start and EVE must be inside the grid and not walls')
        if self.start == self.eve:
            raise ValueError('Start and EVE must differ for this demo')
        if self.noise < 0 or self.scan_range < 0:
            raise ValueError('signal_noise and scan_range must be nonnegative')

    def observe_signal(self, pos):
        """Return noisy Manhattan-distance measurement (no hidden position)."""
        true_distance = distance(pos, self.eve)
        return max(0, true_distance + self.rng.randint(-self.noise, self.noise))

    def scan(self, pos):
        """A scan checks whether EVE is within Manhattan scan range."""
        return distance(pos, self.eve) <= self.scan_range

    def legal_neighbors(self, pos):
        return [(direction, (pos[0] + dx, pos[1] + dy))
                for direction, (dx, dy) in MOVES.items()
                if (pos[0] + dx, pos[1] + dy) in self.cells]


class Agent:
    def __init__(self, env, config):
        self.env = env
        self.pos = env.start
        self.max_battery = config.get('battery', 30)
        self.battery = self.max_battery
        self.move_cost = config.get('move_cost', 1)
        self.scan_cost = config.get('scan_cost', 2)
        self.time_limit = config.get('time_limit', 60)
        self.time = 0
        self.visits = {self.pos: 1}
        self.log = []
        self.found = False
        self.scanned = set()
        # Uniform prior: agent doesn't know EVE's actual position.
        possible = [p for p in env.cells if p != env.start]
        self.belief = {p: 1 / len(possible) for p in possible}

    def update(self, likelihood):
        weighted = {p: prior * likelihood(p) for p, prior in self.belief.items()}
        total = sum(weighted.values())
        if total > 0:
            self.belief = {p: w / total for p, w in weighted.items()}
        # If impossible/noisy evidence contradicts the model, preserve prior.

    def update_signal(self, reading):
        noise = self.env.noise
        self.update(lambda p: 1.0 if abs(distance(self.pos, p) - reading) <= noise else 0.0)

    def update_scan(self, positive):
        radius = self.env.scan_range
        self.update(lambda p: 1.0 if (distance(self.pos, p) <= radius) == positive else 0.0)

    def best_guess(self):
        return max(self.belief, key=self.belief.get)

    def record(self, action, observation, reason):
        guess = self.best_guess()
        self.log.append({'step': self.time, 'position': list(self.pos),
                         'battery': self.battery, 'action': action,
                         'observation': observation, 'reason': reason,
                         'best_guess': list(guess),
                         'confidence': round(self.belief[guess], 4)})

    def step(self):
        if self.time >= self.time_limit or self.found:
            return False
        # At a recharge station, refill when low.
        if self.pos in self.env.recharge and self.battery < self.max_battery // 2:
            self.battery = self.max_battery
            self.time += 1
            self.record('recharge', 'battery restored', 'Low battery at a recharge station')
            return True
        if self.battery < self.move_cost:
            self.record('stop', 'insufficient battery', 'Cannot afford a move')
            return False
        # Scan when the probability of EVE being nearby is high enough.
        nearby_prob = sum(prob for p, prob in self.belief.items()
                          if distance(self.pos, p) <= self.env.scan_range)
        if (self.pos not in self.scanned and self.battery >= self.scan_cost
                and nearby_prob >= 0.35):
            self.battery -= self.scan_cost
            self.time += 1
            positive = self.env.scan(self.pos)
            self.scanned.add(self.pos)
            self.update_scan(positive)
            self.record('scan', {'eve_nearby': positive},
                        f'Nearby probability was {nearby_prob:.2f}')
            if positive and self.pos == self.env.eve:
                self.found = True
            return True
        neighbors = self.env.legal_neighbors(self.pos)
        if not neighbors:
            self.record('stop', 'no accessible neighbors', 'Agent is trapped')
            return False
        # Select next cell using expected distance under current belief,
        # a revisit penalty, and a low-battery preference for recharge.
        low_battery = self.battery <= max(4, self.max_battery // 4)
        def score(item):
            _, target = item
            expected = sum(prob * distance(target, p) for p, prob in self.belief.items())
            revisit_penalty = self.visits.get(target, 0) * 1.5
            recharge_bonus = -8 if low_battery and target in self.env.recharge else 0
            return expected + revisit_penalty + recharge_bonus
        direction, target = min(neighbors, key=score)
        self.pos = target
        self.visits[target] = self.visits.get(target, 0) + 1
        self.battery -= self.move_cost
        self.time += 1
        reading = self.env.observe_signal(self.pos)
        self.update_signal(reading)
        self.found = self.pos == self.env.eve
        self.record('move ' + direction, {'distance_signal': reading,
                    'eve_found': self.found},
                    'Minimize expected distance, revisits, and energy risk')
        return True

    def run(self):
        initial = self.env.observe_signal(self.pos)
        self.update_signal(initial)
        self.record('initial observation', {'distance_signal': initial},
                    'Start with uniform prior, update from first sensor reading')
        while self.step():
            pass
        guess = self.best_guess()
        return {'found': self.found, 'final_position': list(self.pos),
                'inferred_eve_location': list(guess),
                'confidence': round(self.belief[guess], 4),
                'battery_remaining': self.battery, 'time_used': self.time,
                'evidence_count': len(self.log),
                'recommended_next_step': 'Mission complete' if self.found else
                    ('Recharge or extend mission budget' if self.battery < self.move_cost
                     else 'Continue scanning high-probability cells'),
                'trace': self.log}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='sample_config.json')
    parser.add_argument('--output', default='mission_report.json')
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding='utf-8'))
    env = Environment(config)
    report = Agent(env, config).run()
    Path(args.output).write_text(json.dumps(report, indent=2), encoding='utf-8')
    for item in report['trace']:
        print(f"{item['step']:02d} | {item['action']:<20} | pos={item['position']} "
              f"| battery={item['battery']:02d} | guess={item['best_guess']} "
              f"| confidence={item['confidence']:.2f}")
    print('\nFINAL REPORT:', json.dumps({k: v for k, v in report.items() if k != 'trace'}, indent=2))
    print('Saved:', args.output)


if __name__ == '__main__':
    main()
